
ma_f_doss=function() {
	color <- c("blue", "red", "green", "powderblue", "tan1", "yellow")

	m = ma_f("variete_1")

	max_x <- max(m$ite)
	max_y <- max(m$case_1,m$case_2,m$case_3,m$case_4,m$case_5)
	plot(m$ite, m$case_1*m$case_2*m$case_3*m$case_4*m$case_5, type="l", col=color[1], xlim=c(0,max_x), ylim=c(0,max_y), main = "", xlab="", ylab="")

	m = ma_f("variete_3")
	max_x <- max(m$ite)
	max_y <- max(m$case_1,m$case_2,m$case_3,m$case_4,m$case_5)
	par(new = TRUE)
	plot(m$ite, m$case_1*m$case_2*m$case_3*m$case_4*m$case_5, type="l", col=color[2], xlim=c(0,max_x), ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	m = ma_f("variete_5")
	max_x <- max(m$ite)
	max_y <- max(m$case_1,m$case_2,m$case_3,m$case_4,m$case_5)
	par(new = TRUE)
	plot(m$ite, m$case_1*m$case_2*m$case_3*m$case_4*m$case_5, type="l", col=color[3], xlim=c(0,max_x), ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	m = ma_f("variete_7")
	max_x <- max(m$ite)
	max_y <- max(m$case_1,m$case_2,m$case_3,m$case_4,m$case_5)
	par(new = TRUE)
	plot(m$ite, m$case_1*m$case_2*m$case_3*m$case_4*m$case_5, type="l", col=color[4], xlim=c(0,max_x), ylim=c(0,max_y), axes=FALSE, ann=FALSE)
	
	m = ma_f("variete_9")
	max_x <- max(m$ite)
	max_y <- max(m$case_1,m$case_2,m$case_3,m$case_4,m$case_5)
	par(new = TRUE)
	plot(m$ite, m$case_1*m$case_2*m$case_3*m$case_4*m$case_5, type="l", col=color[5], xlim=c(0,max_x), ylim=c(0,max_y), axes=FALSE, ann=FALSE)
	
	title(main = "Taux classification des cases suivant variété",
      xlab = "Nombre d'itérations (x4000)", ylab = "Produit du pourcentage d'éléments majorant les cases"
      )
	par(new = TRUE)
	legend("bottomright", legend=c("1/10","3/10","5/10","7/10","9/10"), col=color, lty=1:1, cex=0.8, box.lty=0)

}

ma_f=function(doss) {
	setwd(doss)
	print(doss)
	init=TRUE
	nbr_file = 0
	for(var in dir()) {
		print(var)
		#print(read.table(var, header=TRUE, sep="\t"))
		if (init==TRUE) {
			nb_ligne <- list()
			data_end <- read.table(var, header=T, sep="\t")

			a <- numeric(101)
			m <- data.frame(ite=a,case_1=a,case_2=a,case_3=a,case_4=a,case_5=a)
			for(i in 1:101) {
				print(i)
				m$ite[i] = i
				m$case_1[i] = max(data_end$ca1_cl1[i],data_end$ca1_cl2[i],data_end$ca1_cl3[i])/(data_end$ca1_cl1[i]+data_end$ca1_cl2[i]+data_end$ca1_cl3[i])
				m$case_2[i] = max(data_end$ca2_cl1[i],data_end$ca2_cl2[i],data_end$ca2_cl3[i])/(data_end$ca2_cl1[i]+data_end$ca2_cl2[i]+data_end$ca2_cl3[i])
				m$case_3[i] = max(data_end$ca3_cl1[i],data_end$ca3_cl2[i],data_end$ca3_cl3[i])/(data_end$ca3_cl1[i]+data_end$ca3_cl2[i]+data_end$ca3_cl3[i])
				m$case_4[i] = max(data_end$ca4_cl1[i],data_end$ca4_cl2[i],data_end$ca4_cl3[i])/(data_end$ca4_cl1[i]+data_end$ca4_cl2[i]+data_end$ca4_cl3[i])
				m$case_5[i] = max(data_end$ca5_cl1[i],data_end$ca5_cl2[i],data_end$ca5_cl3[i])/(data_end$ca5_cl1[i]+data_end$ca5_cl2[i]+data_end$ca5_cl3[i])
			}

	  	nb_ligne <- nrow(data_end)
			init=FALSE
		}
		else {
			data_temp <- read.table(var, header=T, sep="\t")
			for(i in 1:101) {
				m$ite[i] = m$ite[i] + i
				m$case_1[i] = m$case_1[i] + max(data_temp$ca1_cl1[i],data_temp$ca1_cl2[i],data_temp$ca1_cl3[i])/(data_temp$ca1_cl1[i]+data_temp$ca1_cl2[i]+data_temp$ca1_cl3[i])
				m$case_2[i] = m$case_2[i] + max(data_temp$ca2_cl1[i],data_temp$ca2_cl2[i],data_temp$ca2_cl3[i])/(data_temp$ca2_cl1[i]+data_temp$ca2_cl2[i]+data_temp$ca2_cl3[i])
				m$case_3[i] = m$case_3[i] + max(data_temp$ca3_cl1[i],data_temp$ca3_cl2[i],data_temp$ca3_cl3[i])/(data_temp$ca3_cl1[i]+data_temp$ca3_cl2[i]+data_temp$ca3_cl3[i])
				m$case_4[i] = m$case_4[i] + max(data_temp$ca4_cl1[i],data_temp$ca4_cl2[i],data_temp$ca4_cl3[i])/(data_temp$ca4_cl1[i]+data_temp$ca4_cl2[i]+data_temp$ca4_cl3[i])
				m$case_5[i] = m$case_5[i] + max(data_temp$ca5_cl1[i],data_temp$ca5_cl2[i],data_temp$ca5_cl3[i])/(data_temp$ca5_cl1[i]+data_temp$ca5_cl2[i]+data_temp$ca5_cl3[i])
			}
			#data_end = data_end + data_temp
		}
		nbr_file = nbr_file + 1
	}
	#print(data_end)
	setwd("./../")

	#data_end = data_end / nbr_file

	#print(data_end)
	m = m / nbr_file
	print(m)
	#occur <- matrix(c(max(data_end$ca1_cl1,data_end$ca1_cl2,data_end$ca1_cl3)),ncol=1,byrow=TRUE)
	#a <- numeric(101)
	#m <- array(0:0,c(101,5)) # Tableau à 3 dimensions (longueur de 2 pour chaque dimension)
	#occur <- data(max(data_end$ca1_cl1,data_end$ca1_cl2,data_end$ca1_cl3)/(data_end$ca1_cl1+data_end$ca1_cl2+data_end$ca1_cl3))
	#print(nrow(occur))
	#m <- data.frame(case_1=a,case_2=a,case_3=a,case_4=a,case_5=a)
	#for(i in 1:101) {
	#	m$case_1[i] = max(data_end$ca1_cl1[i],data_end$ca1_cl2[i],data_end$ca1_cl3[i])/(data_end$ca1_cl1[i]+data_end$ca1_cl2[i]+data_end$ca1_cl3[i])
	#	m$case_2[i] = max(data_end$ca2_cl1[i],data_end$ca2_cl2[i],data_end$ca2_cl3[i])/(data_end$ca2_cl1[i]+data_end$ca2_cl2[i]+data_end$ca2_cl3[i])
	#	m$case_3[i] = max(data_end$ca3_cl1[i],data_end$ca3_cl2[i],data_end$ca3_cl3[i])/(data_end$ca3_cl1[i]+data_end$ca3_cl2[i]+data_end$ca3_cl3[i])
	#	m$case_4[i] = max(data_end$ca4_cl1[i],data_end$ca4_cl2[i],data_end$ca4_cl3[i])/(data_end$ca4_cl1[i]+data_end$ca4_cl2[i]+data_end$ca4_cl3[i])
	#	m$case_5[i] = max(data_end$ca5_cl1[i],data_end$ca5_cl2[i],data_end$ca5_cl3[i])/(data_end$ca5_cl1[i]+data_end$ca5_cl2[i]+data_end$ca5_cl3[i])
	#print(m$case_1[i])
		#var = max(data_end$ca1_cl1,data_end$ca1_cl2,data_end$ca1_cl3)/(data_end$ca1_cl1+data_end$ca1_cl2+data_end$ca1_cl3)
	#}
	#for(i in 1:dim(m)[1])  # for each row
	#{
  #	for(j in 1:dim(m)[2]) # for each column
  #	{
  #  	 print(m[i,j])   # assign values based on position: product of two indexes
  #	}
	#}
	print(data_end)
	print(m)
	#print(data_end$ite)
	#print(attributes(data_end))

	#max_y <- max(data_end$nb1_elt_t,data_end$nb2_elt_t)
	#plot(data_end$ite, data_end$nb1_elt2, type="l", col=color[1], ylim=c(0,max_y), main = "", xlab="", ylab="")
	#box()
	#title(main = "Type de classification avec 1/2 de variété",
  #    xlab = "Nombre d'itérations", ylab = "Nombre d'éléments"
  #    )
	###Abscisse
	#axis(1, at = seq(0, max(data_end$ite, na.rm = TRUE), by = max(data_end$ite)/10), las=2)
	###la valeur de k permet d'affiner la droite, lorsqu'il y avait trop de variation...
	#k <- 1
	### lty et pch permette de definir respectivement le type de ligne et le type de point
	#lines(data_end$ite, data_end$nb1_elt2, type="l", pch=22, lty=2, col=color[1])
	#axis(2, at = seq(0, 10, by = 1), las=2)
	###rajoute un nouveau plot sur le meme graph
	#par(new = TRUE)

	#par(new = TRUE)

	#plot(data_end$ite, data_end$nb1_elt_t, type="l", col=color[3], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	### POUR 22

	#par(new = TRUE)

	#plot(data_end$ite, data_end$nb2_elt2, type="l", col=color[4], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	#par(new = TRUE)

	#plot(data_end$ite, data_end$nb2_elt3, type="l", col=color[5], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	#par(new = TRUE)

	#plot(data_end$ite, data_end$nb2_elt_t, type="l", col=color[6], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	#par(new = TRUE)
	#legend("topleft", legend=c("12: nbr elt classe 2", "12: nbr elt classe 3","22: nbr elt classe 2", "22: nbr elt classe 3"), col=c("blue", "red", "powderblue", "tan1"), lty=1:1, cex=0.8, box.lty=0)
	#legend(1, 95, legend=c("Element classe2", "Element classe 3"), col=c("blue", "red", "green", "powderblue", "tan1", "yellow"), lty=1:2, cex=0.8)

	return(m)
}