color <- c("blue", "red", "green")
data <- read.table("./test_proba/2016_5_3_11_44/50000-100-petitprince123.dat", header=T, sep="\t")
data_normal <- read.table("./test_proba/2016_5_3_11_44/25000-100-petitprince123.normal.dat", header=T, sep="\t")
max_y <- max(data$proba)
plot(data$ite, data$proba, type="l", col=color[1], ylim=c(0,max_y), axes=FALSE, ann=FALSE)
box()
###Abscisse
axis(1, at = seq(0, max(data$ite, na.rm = TRUE), by = max(data$ite)/10), las=2)
###la valeur de k permet d'affiner la droite
k <- 1
### lty et pch permette de definir respectivement le type de ligne et le type de point
lines(data$ite, filter(data$ptrue, rep(1/k,k)), type="l", pch=22, lty=2, col=color[3])
axis(2, at = seq(0.0, 100.0, by = 10.0), las=2)
###rajoute un nouveau plot sur le meme graph
par(new = TRUE)

plot(data_normal$ite, data_normal$proba, type="l", col=color[2], ylim=c(0,max_y), axes=FALSE, ann=FALSE)
###plot(na.omit(data$deriv), col=color[2], type = "l", axes = FALSE, bty = "n", xlab = "", ylab = "", ylim=c(0,max(data$deriv, na.rm = TRUE)))
###mtext("Derivate",side=4,col=color[2],line=4)
###axis(2, at = seq(min(data$deriv, na.rm = TRUE), max(data$deriv, na.rm = TRUE), by = max(data$deriv, na.rm = TRUE)/10), col=color[2],col.axis=color[2],las=1)