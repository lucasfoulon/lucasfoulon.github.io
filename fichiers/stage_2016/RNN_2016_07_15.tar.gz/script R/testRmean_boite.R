
ma_f=function(doss) {

	ma_f_mean=function(doss){
		setwd(doss)
		init=TRUE
		for(var in dir()) {
			#print(var)
			if (init==TRUE) {
				nb_ligne <- list()
				data_end <- read.table(var, header=T, sep="\t")
		  	nb_ligne <- nrow(data_end)
				init=FALSE
			}
			else {
				data <- read.table(var, header=T, sep="\t")
				if(nrow(data) > max(nb_ligne)) {
					data_temp = data_end
					data_end = data
					data_end[1:nrow(data_temp),] = data_end[1:nrow(data_temp),] + data_temp[1:nrow(data_temp),]
				}
				else {
					data_end[1:nrow(data),] = data_end[1:nrow(data),] + data[1:nrow(data),]
				}
		  	nb_ligne[length(nb_ligne)+1] <- nrow(data)
			}
			#print(data_end)
		}
		print(sort(nb_ligne))

		remove <- c (101)
		print("moyenne du nbr de ligne ayant depasser 0.65")
		print(mean(nb_ligne [! nb_ligne %in% remove]))
		print("nbr d'exec ayant depasser 0.65")
		print(length(nb_ligne [! nb_ligne %in% remove]))
		print("moyenne du nbr de ligne")
		print(mean(nb_ligne))
		#print(data_end)
		setwd("./../")

		len_total=length(nb_ligne)
		#print(len_total)
		last=0

		print("debut boucle")

		for(var in sort(nb_ligne)) {
			#print(var)
			#print(len_total)

			if(last==0){
				data_end[(last+1):var,] = data_end[(last+1):var,] / len_total
				len_total = len_total - 1
				last=var
			}
			else {
				
				if (last==var) {
					len_total = len_total - 1
				}
				else {
					data_end[(last+1):var,] = data_end[(last+1):var,] / len_total
					len_total = len_total - 1
					last = var
				}
			}
		}
		#print(data_end)

		return(nb_ligne)
	}

	data_end = ma_f_mean(doss)

	color <- c("blue", "red", "green", "powderblue", "tan1", "yellow", "snow4","orange4","lightsteelblue3")

	data<-data.frame(stat1=data_end)
	#boxplot(data)
	###Abscisse
	#axis(1, at = seq(0, max(data_end$ite, na.rm = TRUE), by = max(data_end$ite)/10), las=2)
	###la valeur de k permet d'affiner la droite, lorsqu'il y avait trop de variation...
	#k <- 1
	### lty et pch permette de definir respectivement le type de ligne et le type de point
	#lines(data_end$ite, data_end$nb1_elt2, type="l", pch=22, lty=2, col=color[1])
	#axis(2, at = seq(0, 10, by = 1), las=2)
	###rajoute un nouveau plot sur le meme graph
	#or(i in 2:9) {
		#if(i == 5 || i == 2 || i == 9) {
			#name_file = paste("mean", i, sep="")
			#print(name_file)
			#data_end = ma_f_mean(name_file)
			#name_stat = paste("Stat", i, sep="")
			#data<-data.frame(data,stat2=data_end)
	  	#rug(data$mean,side=2,col=i)
		#}
	#}
	data_end = ma_f_mean("mean2")
	data<-data.frame(data,stat2=data_end)
	data_end = ma_f_mean("mean3")
	data<-data.frame(data,stat3=data_end)
	data_end = ma_f_mean("mean4")
	data<-data.frame(data,stat4=data_end)
	data_end = ma_f_mean("mean5")
	data<-data.frame(data,stat5=data_end)
	data_end = ma_f_mean("mean6")
	data<-data.frame(data,stat6=data_end)
	data_end = ma_f_mean("mean7")
	data<-data.frame(data,stat7=data_end)
	data_end = ma_f_mean("mean8")
	data<-data.frame(data,stat8=data_end)
	data_end = ma_f_mean("mean9")
	data<-data.frame(data,stat9=data_end)
	boxplot(data)
	title(main = "Itérations pour atteindre prediction de 65% (majoré à 100 itérations)",
      xlab = "statistique pour n/10 variété", ylab = "nombre d'itération (x4000)"
      )

	#par(new = TRUE)
	#legend("bottomright", legend=c("n = 1", "n = 2", "n = 3", "n = 4", "n = 5", "n = 6", "n = 7", "n = 8", "n = 9"), 
	#	col=color, lty=1:1, cex=0.8)

	#ns    <- c(15,28,10,20,35)
	#n     <- length(ns)
	#group <- factor(rep(1:n,ns),labels=paste("g",1:n,sep=""))
	#print(group)
	#data  <- rnorm(length(group),mean=100+(as.numeric(group)-2)^2)
	#print(data)
	#boxplot(data~group,border=1:n,xlab="Groupe",ylab="Réponse",varwidth=T)
	#for (i in 1:n) {
	#}


	#par(new = TRUE)

	#plot(data_end$ite, data_end$nb1_elt_t, type="l", col=color[3], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	### POUR 22

	#par(new = TRUE)

	#plot(data_end$ite, data_end$nb2_elt2, type="l", col=color[4], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	#par(new = TRUE)

	#plot(data_end$ite, data_end$nb2_elt3, type="l", col=color[5], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	#par(new = TRUE)

	#plot(data_end$ite, data_end$nb2_elt_t, type="l", col=color[6], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	#par(new = TRUE)
	#legend("topleft", legend=c("12: nbr elt classe 2", "12: nbr elt classe 3","22: nbr elt classe 2", "22: nbr elt classe 3"), col=c("blue", "red", "powderblue", "tan1"), lty=1:1, cex=0.8, box.lty=0)
	#legend(1, 95, legend=c("Element classe2", "Element classe 3"), col=c("blue", "red", "green", "powderblue", "tan1", "yellow"), lty=1:2, cex=0.8)

}