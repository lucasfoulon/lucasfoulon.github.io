
ma_f=function(doss) {
	setwd(doss)
	init=TRUE
	nbr_file = 0
	for(var in dir()) {
		if (init==TRUE) {
			nb_ligne <- list()
			data_end <- read.table(var, header=T, sep="\t")
	  	nb_ligne <- nrow(data_end)
			init=FALSE
			nbr_file = nbr_file + 1
		}
		else {
			data_temp <- read.table(var, header=T, sep="\t")
			data_end = data_end + data_temp
			nbr_file = nbr_file + 1
		}
	}
	#print(data_end)
	setwd("./../")

	data_end = data_end / nbr_file

	#print(data_end)
	print(nbr_file)

	color <- c("blue", "red", "green", "powderblue", "tan1", "yellow")

	#max_x <- data_end$ite*2
	#max_y <- max(data_end$mean_true_lettre,data_end$mean_true_mot)
	max_y <- max(data_end$court_mono,data_end$court_bi,data_end$long_mono,data_end$long_bi)
	min_y <- min(data_end$court_mono,data_end$court_bi,data_end$long_mono,data_end$long_bi)
	#box()

	#par(new = TRUE)
	#plot(data_end$ite, data_end$mean_true_lettre, type="l", col=color[1], ylim=c(0,max_y), main = "", xlab="", ylab="")
	#par(new = TRUE)
	#plot(data_end$ite, data_end$mean_true_mot, type="l", col=color[2], ylim=c(0,max_y), main = "", xlab="", ylab="")
	#par(new = TRUE)

	#plot(data_end$ite, data_end$court_mono, type="l", col=color[3], ylim=c(0,max_y), main = "", xlab="", ylab="")
	#par(new = TRUE)
	#plot(data_end$ite, data_end$long_mono, type="l", col=color[5], ylim=c(0,max_y), axes=FALSE, ann=FALSE)
	k <- 7
	plot(data_end$ite[0:225], filter(data_end$court_mono[0:225], rep(1/k,k)), type="l", col=color[3], ylim=c(min_y,max_y), main = "", xlab="", ylab="")
	par(new = TRUE)
	plot(data_end$ite[0:225], filter(data_end$long_mono[0:225], rep(1/k,k)), type="l", col=color[5], ylim=c(min_y,max_y), axes=FALSE, ann=FALSE)

	print(data_end$ite[0:225])
	data_end$ite = data_end$ite*2
	print(data_end$ite[0:113])

	par(new = TRUE)
	#plot(data_end$ite[0:150], data_end$court_bi[0:150], type="l", col=color[1], ylim=c(0,max_y), axes=FALSE, ann=FALSE)
	plot(data_end$ite[0:113], filter(data_end$court_bi[0:113], rep(1/k,k)), type="l", col=color[1], ylim=c(min_y,max_y), axes=FALSE, ann=FALSE)
	#plot(data_end$ite, data_end$court_bi, type="l", col=color[1], ylim=c(0,max_y), axes=FALSE, ann=FALSE)
	par(new = TRUE)
	#plot(data_end$ite[0:150], data_end$long_bi[0:150], type="l", col=color[2], ylim=c(0,max_y), axes=FALSE, ann=FALSE)
	plot(data_end$ite[0:113], filter(data_end$long_bi[0:113], rep(1/k,k)), type="l", col=color[2], ylim=c(min_y,max_y), axes=FALSE, ann=FALSE)
	#plot(data_end$ite, data_end$long_bi, type="l", col=color[2], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	par(new = TRUE)
	title(main = "Pourcentage de règles respectées",
	#title(main = "Taux de prédiction durant l'apprentissage",
      xlab = "Nombre d'itérations", ylab = "Taux en pourcentage"
      )
	legend("bottomright", legend=c("court terme, niveau 1 seul","court terme, 2 niveaux","long terme, niveau 1 seul", "long terme, 2 niveaux"), col=c("green", "blue", "tan1", "red"), lty=1:1, cex=0.8, box.lty=0)
	#legend("bottomright", legend=c("moyenne niveau 1","moyenne niveau 2"), col=c("blue", "red"), lty=1:1, cex=0.8, box.lty=0)
	#legend(1, 95, legend=c("Element classe2", "Element classe 3"), col=c("blue", "red", "green", "powderblue", "tan1", "yellow"), lty=1:2, cex=0.8)

}