
ma_f_g=function() {

	data_end = ma_f("12_22_1")

	color <- c("blue", "red", "darkorchid4", "darkorange1", "powderblue", "green", "tan1")

	max_y <- max(data_end$nb1_elt_t,data_end$nb2_elt_t)
	plot(data_end$ite,  (data_end$nb1_elt2+data_end$nb2_elt2)/2, type="l", col=color[1], ylim=c(0,max_y), main = "", xlab="", ylab="")
	box()
	title(main = "Nombre d'élément de classe 2 et 3",
      xlab = "Nombre d'itérations", ylab = "Nombre d'éléments"
      )
	###Abscisse
	#axis(1, at = seq(0, max(data_end$ite, na.rm = TRUE), by = max(data_end$ite)/10), las=2)
	###la valeur de k permet d'affiner la droite, lorsqu'il y avait trop de variation...
	#k <- 1
	### lty et pch permette de definir respectivement le type de ligne et le type de point
	#lines(data_end$ite, (data_end$nb1_elt2+data_end$nb2_elt2)/2, type="l", pch=22, lty=2, col=color[1])
	#axis(2, at = seq(0, 10, by = 1), las=2)
	###rajoute un nouveau plot sur le meme graph
	par(new = TRUE)

	plot(data_end$ite, (data_end$nb1_elt3+data_end$nb2_elt3)/2, type="l", col=color[2], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	#par(new = TRUE)

	#plot(data_end$ite, data_end$nb2_elt2, type="l", col=color[3], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	#par(new = TRUE)

	#plot(data_end$ite, data_end$nb2_elt3, type="l", col=color[4], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	data_end = ma_f("12_22_5")

	par(new = TRUE)

	plot(data_end$ite, (data_end$nb1_elt2+data_end$nb2_elt2)/2, type="l", col=color[3], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	par(new = TRUE)

	plot(data_end$ite, (data_end$nb1_elt3+data_end$nb2_elt3)/2, type="l", col=color[4], ylim=c(0,max_y), axes=FALSE, ann=FALSE)


	data_end = ma_f("12_22_9")

	par(new = TRUE)

	plot(data_end$ite, (data_end$nb1_elt2+data_end$nb2_elt2)/2, type="l", col=color[5], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	par(new = TRUE)

	plot(data_end$ite, (data_end$nb1_elt3+data_end$nb2_elt3)/2, type="l", col=color[6], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	#par(new = TRUE)

	#plot(data_end$ite, data_end$nb2_elt2, type="l", col=color[5], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	#par(new = TRUE)

	#plot(data_end$ite, data_end$nb2_elt3, type="l", col=color[6], ylim=c(0,max_y), axes=FALSE, ann=FALSE)

	par(new = TRUE)
	legend("topleft", legend=c("variété 1/10, classe 2", "variété 1/2, classe 2","variété 9/10, classe 2"), col=c("blue", "darkorchid4", "powderblue"), lty=1:1, cex=0.8, box.lty=0)
	
	par(new = TRUE)
	legend("topright", legend=c("variété 1/10, classe 3", "variété 1/2, classe 3","variété 9/10, classe 3"), col=c("red", "darkorange1", "green"), lty=1:1, cex=0.8, box.lty=0)
	#legend(1, 95, legend=c("Element classe2", "Element classe 3"), col=c("blue", "red", "green", "powderblue", "tan1", "yellow"), lty=1:2, cex=0.8)


}


ma_f=function(doss) {
	setwd(doss)
	init=TRUE
	for(var in dir()) {
		if (init==TRUE) {
			nb_ligne <- list()
			data_end <- read.table(var, header=T, sep="\t")
	  	nb_ligne <- nrow(data_end)
			init=FALSE
		}
		else {
			data <- read.table(var, header=T, sep="\t")
			if(nrow(data) > max(nb_ligne)) {
				data_temp = data_end
				data_end = data
				data_end[1:nrow(data_temp),] = data_end[1:nrow(data_temp),] + data_temp[1:nrow(data_temp),]
			}
			else {
				data_end[1:nrow(data),] = data_end[1:nrow(data),] + data[1:nrow(data),]
			}
	  	nb_ligne[length(nb_ligne)+1] <- nrow(data)
		}
	}
	print(sort(nb_ligne))
	print(data_end)
	setwd("./../")

	len_total=length(nb_ligne)
	print(len_total)
	last=0

	print("debut boucle")

	for(var in sort(nb_ligne)) {
		print(var)
		print(len_total)

		if(last==0){
			data_end[(last+1):var,] = data_end[(last+1):var,] / len_total
			len_total = len_total - 1
			last=var
		}
		else {
			
			if (last==var) {
				len_total = len_total - 1
			}
			else {
				data_end[(last+1):var,] = data_end[(last+1):var,] / len_total
				len_total = len_total - 1
				last = var
			}
		}
		print(data_end)
	}

	return(data_end)
}